# Piston Detection > 2023-06-24 12:38pm
https://universe.roboflow.com/amrita-vishwa-vidyapeetham-wtgwo/piston-detection

Provided by a Roboflow user
License: CC BY 4.0

